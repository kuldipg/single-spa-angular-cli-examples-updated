import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'home-route2',
  templateUrl: './route2.component.html',
  styleUrls: ['./route2.component.css']
})
export class Route2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
